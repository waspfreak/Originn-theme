<?php
/* Custom functions code goes here. */